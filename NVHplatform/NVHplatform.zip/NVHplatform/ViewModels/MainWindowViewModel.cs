﻿using CommunityToolkit.Mvvm.ComponentModel;
using NVHplatform.Views;

namespace NVHplatform.ViewModels
{
    public class MainWindowViewModel : ObservableObject
    {
        public WaveformChartViewModel WaveformVM { get; }
        public SpectrumChartViewModel SpectrumVM { get; }
        public FluctuationChartViewModel FluctuationVM { get; }

        private object currentContent;
        public object CurrentContent
        {
            get => currentContent;
            set => SetProperty(ref currentContent, value);
        }

        public MainWindowViewModel(
            WaveformChartViewModel waveformVM,
            SpectrumChartViewModel spectrumVM,
            FluctuationChartViewModel fluctuationVM)
        {
            WaveformVM = waveformVM;
            SpectrumVM = spectrumVM;
            FluctuationVM = fluctuationVM;

            // 初始化主内容为集成三图页面
            CurrentContent = new ChartsView(WaveformVM, SpectrumVM, FluctuationVM);
        }
    }
}
