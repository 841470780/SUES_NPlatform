﻿using CommunityToolkit.Mvvm.ComponentModel;
using NAudio.Wave;
using NVHplatform.Models;
using System;
using System.Collections.ObjectModel;
using System.IO;

namespace NVHplatform.ViewModels
{
    public class RecordingViewModel : ObservableObject
    {
        public string RecordingSavePath => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Recordings");

        private readonly AudioRecorder recorder;

        private ObservableCollection<WaveInCapabilities> audioDevices = new ObservableCollection<WaveInCapabilities>();
        public ObservableCollection<WaveInCapabilities> AudioDevices
        {
            get => audioDevices;
            set => SetProperty(ref audioDevices, value);
        }

        private string statusText = "准备就绪";
        public string StatusText
        {
            get => statusText;
            set => SetProperty(ref statusText, value);
        }

        private double volumeLevel;
        public double VolumeLevel
        {
            get => volumeLevel;
            set => SetProperty(ref volumeLevel, value);
        }

        private float recordingVolume = 100f;
        public float RecordingVolume
        {
            get => recordingVolume;
            set
            {
                if (SetProperty(ref recordingVolume, value))
                {
                    SetRecordingVolume(value);  // 手动调用设置方法
                }
            }
        }

        public RecordingViewModel()
        {
            recorder = new AudioRecorder();
            recorder.RawAudioBufferAvailable += OnRawAudioBufferAvailable;
            recorder.VolumeLevelChanged += OnVolumeLevelChanged;

            LoadAudioDevices();
            SetRecordingVolume(RecordingVolume);
        }

        private void OnRawAudioBufferAvailable(object sender, float[] samples)
        {
            // TODO: 可触发图表更新，或通过委托传出
        }

        private void OnVolumeLevelChanged(object sender, float volume)
        {
            VolumeLevel = volume * 100;
        }

        private void SetRecordingVolume(float scalar)
        {
            recorder.SetSystemRecordingVolume(scalar / 100f);
        }

        private void LoadAudioDevices()
        {
            AudioDevices.Clear();
            for (int i = 0; i < WaveIn.DeviceCount; i++)
            {
                AudioDevices.Add(WaveIn.GetCapabilities(i));
            }
        }

        public void StartRecording(int deviceIndex)
        {
            recorder.DeviceNumber = deviceIndex;
            recorder.StartRecording();
            StatusText = "正在录音...";
        }

        public void StopRecording()
        {
            recorder.StopRecording();
            StatusText = "录音已停止";
        }
    }
}
