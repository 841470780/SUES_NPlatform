﻿using System.Windows.Controls;

namespace NVHplatform.Views
{
    public partial class FluctuationChartView : UserControl
    {
        public FluctuationChartView()
        {
            InitializeComponent();
        }
    }
}
