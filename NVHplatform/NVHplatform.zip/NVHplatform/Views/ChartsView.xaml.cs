﻿using System.Windows.Controls;
using NVHplatform.ViewModels;

namespace NVHplatform.Views
{
    public partial class ChartsView : UserControl
    {
        public ChartsView(WaveformChartViewModel waveformVM, SpectrumChartViewModel spectrumVM, FluctuationChartViewModel fluctuationVM)
        {
            InitializeComponent();
            // 设置DataContext为匿名对象，便于三张图分别绑定
            this.DataContext = new
            {
                WaveformVM = waveformVM,
                SpectrumVM = spectrumVM,
                FluctuationVM = fluctuationVM
            };
        }
    }
}
