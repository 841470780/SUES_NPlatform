﻿using MahApps.Metro.Controls;
using NVHplatform.ViewModels;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;


namespace NVHplatform.Views
{
    public partial class MainWindow : MetroWindow, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public MainWindow()
        {
            InitializeComponent();

            // 正确写法：先 new 三个子 ViewModel
            var waveformVM = new WaveformChartViewModel();
            var spectrumVM = new SpectrumChartViewModel();
            var fluctuationVM = new FluctuationChartViewModel();

            // 传给 MainWindowViewModel
            DataContext = new MainWindowViewModel(waveformVM, spectrumVM, fluctuationVM);
        }

        
    }
}
